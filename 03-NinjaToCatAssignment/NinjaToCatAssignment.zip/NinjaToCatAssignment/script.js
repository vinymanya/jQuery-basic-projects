$(document).ready(function(){
	$("img").click(function(){	
		var cat = $(this).attr("src");
		var ninja = $(this).attr("data-alt-src");
		console.log(cat, ninja);

		$(this).attr("data-alt-src", cat);
		$(this).attr("src", ninja);

	});

	// $("button").click(function(){
	// 	$("img").show($(this).attr("src"));
	// });

});
